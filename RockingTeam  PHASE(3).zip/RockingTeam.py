import subprocess
import os
import time
import psutil
import random

def check_os_vulnerabilities():
    os_name = get_os_name()
    if os_name == 'win32':
        vulnerable_patches = get_vulnerable_patches()
        if vulnerable_patches:
            print(f"Vulnerabilities found for patches: {', '.join(vulnerable_patches)}")
            print("Please update your system by installing the necessary patches.")
        else:
            print("No known vulnerabilities found for patches.")

def get_os_name():
    # Add logic to determine the operating system name
    return os.name

def get_vulnerable_patches():
    # Simulated function - replace with actual logic to check for missing patches
    patches = ['KB500135', 'KB500140', 'KB500144', 'KB500152', 'KB500160']
    return [patch for patch in patches if not is_patch_installed(patch)]

def is_patch_installed(patch):
    # Simulated function - replace with actual logic to check if the patch is installed
    return True  # Replace this with your implementation

def mark_infected_files(directory):
    infected_files = []
    for dirname, _, filenames in os.walk(directory):
        for filename in filenames:
            if filename.endswith('.py'):
                file_path = os.path.join(dirname, filename)
                try:
                    with open(file_path, 'r') as file:
                        file_contents = file.read()

                    if "THIS FILE IS INFECTED" not in file_contents:
                        file_contents = "# THIS FILE IS INFECTED\n" + file_contents

                        with open(file_path, 'w') as file:
                            file.write(file_contents)

                        infected_files.append(file_path)
                        print(f"Infected: {file_path}")
                        time.sleep(3)
                    else:
                        print(f"Already infected: {file_path}")
                        time.sleep(3)
                except Exception as e:
                    print(f"Error processing file: {file_path} - {e}")
    # return infected_files

def cnt():
    cont=True
    val=str(input("\n\nDo you want to Continue?(y/n):"))
    if val=='y':
        cont=True
    elif val=='n':
        cont=False
    else:cont=True
    return cont


def vrfctn():
    try:
        # Run the SFC scan command
        subprocess.run(['sfc', '/scannow'], check=True)
        print("RTvirus Verification Completed!")
        time.sleep(2)
    except subprocess.CalledProcessError as e:
        print(f"Error during RTvirus scan: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

def check_cpu_speed():
    max_cpu_speed = psutil.cpu_freq().max  # Maximum CPU speed
    current_cpu_speed = psutil.cpu_freq().current
    print(f"\nCPU CLOCK...\n\t|{current_cpu_speed}|")
    time.sleep(2)
    print(f"\nMAX CPU CLOCK...\n\t|{max_cpu_speed}|")
    time.sleep(1)
    if current_cpu_speed > max_cpu_speed:
        print(f"\n\t|DANGER|\n\n")
        time.sleep(1)
    else:
        print(f"\n\t|SAFE|\n\n")
        time.sleep(1)

def get_memory_speed():
    cmd = 'wmic MemoryChip get Speed'
    try:
        output = subprocess.check_output(cmd, shell=True, text=True)
        speeds = [int(speed) for speed in output.strip().split('\n') if speed.isdigit()]
        max_memory_speed = max(speeds) if speeds else 0

        return max_memory_speed
    except subprocess.CalledProcessError as e:
        print(f"Error: {e}")
        return 0

def get_current_memory_speed():
    mem_info = psutil.virtual_memory()
    return mem_info[2]
def check_memory_speed():
    current_speed = get_current_memory_speed()
    # # print(f"Current Memory Speed: {current_speed} MHz")
    max_supported_speed =current_speed  # Replace this with your system's maximum supported memory speed
    current_memory_speed = get_memory_speed()
    print(f"\nMemory CLOCK...\n\t|{current_memory_speed}|")
    time.sleep(2)
    print(f"\nMAX MEMORY CLOCK...\n\t|{current_memory_speed}|")
    time.sleep(1)
    if current_memory_speed > current_memory_speed:
        print(f"\n\t|DANGER|\n\n")
        time.sleep(1)
    else:
        print(f"\n\t|SAFE|\n\n")
        time.sleep(1)




def run_sfc_scan():
    try:
        # run_sfc_scan()
        check_os_vulnerabilities()
        infected_files = mark_infected_files('C:\\Windows\\System32')  # Replace with the desired directory
        print("Infected files:", infected_files)
    except subprocess.CalledProcessError as e:
        print(f"Error during SFC scan: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
def run_sfc_scanfile():
    try:
        # Run the SFC scan command
        subprocess.run(['sfc', '/verifyonly'], check=True)
        print("\rScan completed successfully.",end="\r")
    except subprocess.CalledProcessError as e:
        print(f"Error during SFC scan: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    cntnu=True
    try:
        print("Installing",end="\r")
        time.sleep(3)
        print("Installed Successfully!")
        time.sleep(2)
        print("\n")
        print("WELCOME TO THE RTvirus!\n\t\t by- Rocking Team\n")
        # vrfctn()
        # time.sleep(2)

        while cntnu==True:
            tdo = int(input("\tSCAN?\n\t\t(1)Operative System.\n\t\t(2)Hardware System.\n\t:-"))
            if tdo == 1:

                vrfctn()
                time.sleep(2)

                print("\nOS Venerability Scan")
                time.sleep(1)
                print("Continuing Scan.",end="")
                time.sleep(1)
                print(".",end="")
                time.sleep(1)
                print(".",end="")
                # doo=int(input("\t:-"))
                # if doo==2:
                print("\nRTvirus",end=" ")
                directory_path = r'C:\Windows\System32'

                # List all files in the directory
                files = os.listdir(directory_path)
                for file_name in files:
                    # time.sleep(1)
                    print(f"SCANNING...\t{file_name}", end="\r")
                    # time.sleep(1)
                    print("|COMPLETED|\n", end="\r")
                    # print("Scaning.",end="")
                    # time.sleep(tme)

                print("\n.", end="")
                # time.sleep(1)
                print(".", end="")
                # time.sleep(1)
                print(".", end="\n")


                run_sfc_scan()
                cntnu=cnt()
            elif tdo==2:
                check_cpu_speed()
                check_memory_speed()
                cntnu=cnt()
    #
    except:print("Error Occurred!!")
    #
    #
